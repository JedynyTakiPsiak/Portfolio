package com.example.termistor;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.DecimalFormat;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    ImageView iv;
    Bitmap bitmap;
    Canvas canvas;
    Paint paint;
    volatile boolean isRunning = false;  // volatile for thread visibility
    Thread captureThread;

    int fftres = 2048;
    int fs = 12000;
    double f = 3000;
    double[] x = new double[fftres];
    double[] y = new double[fftres];
    double[] P = new double[fftres];
    FFT fft = new FFT(fftres);
    short[] audioBuffer = new short[fftres];

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 1);
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        iv = findViewById(R.id.imageView);
        bitmap = Bitmap.createBitmap(1024, 510, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        paint = new Paint();
        paint.setColor(Color.GREEN);
        iv.setImageBitmap(bitmap);
        canvas.drawColor(Color.BLACK);
    }

    public void setUpMic() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        AudioRecord recorder = new AudioRecord(
                MediaRecorder.AudioSource.MIC,
                fs,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                fftres * 2
        );

        recorder.startRecording();

        while (isRunning) {
            readData(recorder);

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                break;
            }
        }

        recorder.stop();
        recorder.release();
    }
    int liczbatest = 0;
    @SuppressLint("SetTextI18n")
    public void readData(AudioRecord recorder) {
        recorder.read(audioBuffer, 0, fftres);
        for (int i = 0; i < fftres; i++) {
            x[i] = (double) audioBuffer[i] / 32768.0;
            y[i] = 0.0;
        }
        calcfft();
        int peakIndex = 0;
        double max = 0.0;
        for (int i = 0; i < fftres / 2; i++) {
            if (P[i] > max) {
                max = P[i];
                peakIndex = i;
            }
        }

        int finalPeakIndexDAS = peakIndex;
        runOnUiThread(() -> {
            TextView textView3 = findViewById(R.id.textView3);
            textView3.setText("FREQ: " + (finalPeakIndexDAS * fs / fftres));

            double wynik = (((double) finalPeakIndexDAS * fs / fftres) - 1322) / 67.23;
            DecimalFormat df = new DecimalFormat("#.##");
            String wynikZaokraglony = df.format(wynik);

            TextView textView4 = findViewById(R.id.textView4);
            textView4.setText("TEMP: " + wynikZaokraglony + "℃");
        });

        liczbatest++;
        if (liczbatest == 5) {
            Log.d("FFT", "Peak frequency bin: " + peakIndex + ", frequency = " + (peakIndex * fs / fftres) + ", temp = " + (((peakIndex * fs / fftres) - 1322)/67.23));
            liczbatest = 0;
        }
        clearGraph();
        int finalPeakIndex = peakIndex;
        runOnUiThread(() -> drawPeak(finalPeakIndex));
    }

    public void calcfft() {
        fft.fft(x, y);
        double alpha = 0.2;
        for (int i = 0; i < fftres; i++) {
            P[i] = alpha * (x[i] * x[i] + y[i] * y[i]) + (1 - alpha) *
                    P[i];
        }
    }

    public void drawPeak(int bin){
        paint.setColor(Color.YELLOW);
        canvas.drawLine(bin, 502, bin + 1, 0, paint);
        iv.invalidate();
    }
    @SuppressLint("SetTextI18n")
    public void Paka(View view) {
        Button btn = (Button) view;
        if (!isRunning) {
            // START
            isRunning = true;
            captureThread = new Thread(this::setUpMic);
            captureThread.start();
            btn.setText("STOP");
        } else {
            // STOP
            isRunning = false;
            clearGraph();
            if (captureThread != null) {
                captureThread.interrupt();
            }
            btn.setText("START");
        }
    }
    public void clearGraph() {
        canvas.drawColor(Color.BLACK);
    }
}